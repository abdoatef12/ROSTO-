package dev.rosto.browser;

import android.net.Uri;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

/** ROSTO blocklist: forbidden sites, forbidden search words, ad/tracker hosts. */
public class Blocklist {

    private static final String[] HARAM = {
            // adult
            "pornhub.com", "xvideos.com", "xnxx.com", "xhamster.com", "redtube.com", "youporn.com",
            "spankbang.com", "brazzers.com", "chaturbate.com", "stripchat.com", "onlyfans.com",
            "rule34.xxx", "e-hentai.org", "nhentai.net", "hentaihaven.xxx", "tube8.com", "eporner.com",
            "bongacams.com", "livejasmin.com", "cam4.com", "motherless.com", "fapello.com",
            // gambling
            "bet365.com", "1xbet.com", "melbet.com", "22bet.com", "betwinner.com", "linebet.com",
            "mostbet.com", "stake.com", "betway.com", "888casino.com", "pokerstars.com",
            "bovada.lv", "draftkings.com", "fanduel.com", "parimatch.com", "1win.com",
            // forbidden dating
            "ashleymadison.com", "adultfriendfinder.com", "tinder.com"
    };

    private static final String[] TRACKERS = {
            "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com",
            "adnxs.com", "taboola.com", "outbrain.com", "popads.net", "propellerads.com", "exoclick.com",
            "trafficjunky.com", "juicyads.com", "adsterra.com", "popcash.net", "hilltopads.net",
            "google-analytics.com", "googletagmanager.com", "scorecardresearch.com", "hotjar.com",
            "mixpanel.com", "criteo.com", "amazon-adsystem.com", "adform.net", "rubiconproject.com",
            "pubmatic.com", "openx.net", "moatads.com", "quantserve.com", "bat.bing.com"
    };

    private static final Pattern HOST_PATTERN = Pattern.compile(
            "(porn|xvideo|xnxx|xhamster|hentai|xxx|nsfw|camgirl|sexcam|sexvid|escort|casino|1xbet|betwinner|megapari)",
            Pattern.CASE_INSENSITIVE);

    private static final Pattern QUERY_EN = Pattern.compile(
            "\\b(porn\\w*|xxx|nude\\w*|naked|hentai|sex\\s*(video|tape|cam|chat)s?|nsfw|onlyfans|casino|betting|escort\\w*)\\b",
            Pattern.CASE_INSENSITIVE);

    private static final Pattern QUERY_AR = Pattern.compile(
            "(سكس|نيك|بورن|اباحي|إباحي|عاريه|عارية|قمار|كازينو|مراهنات|شرموط)");

    private static final String[] QUERY_KEYS = {"q", "query", "p", "text", "search", "k"};

    private static final Set<String> haram = new HashSet<>(Arrays.asList(HARAM));
    private static final Set<String> trackers = new HashSet<>(Arrays.asList(TRACKERS));

    /** Load user-reported hosts (comma separated). */
    public static synchronized void load(String csv) {
        if (csv == null || csv.isEmpty()) return;
        for (String h : csv.split(",")) {
            h = h.trim().toLowerCase(Locale.ROOT);
            if (!h.isEmpty()) haram.add(h);
        }
    }

    public static synchronized boolean addUser(String host) {
        if (host == null) return false;
        host = host.toLowerCase(Locale.ROOT).replaceFirst("^www\\.", "").trim();
        if (host.isEmpty() || !host.contains(".")) return false;
        haram.add(host);
        return true;
    }

    public static synchronized String userCsv() {
        StringBuilder sb = new StringBuilder();
        Set<String> base = new HashSet<>(Arrays.asList(HARAM));
        for (String h : haram) {
            if (base.contains(h)) continue;
            if (sb.length() > 0) sb.append(',');
            sb.append(h);
        }
        return sb.toString();
    }

    private static boolean inSet(String host, Set<String> set) {
        if (host == null) return false;
        host = host.replaceFirst("^www\\.", "");
        String[] parts = host.split("\\.");
        for (int i = 0; i < parts.length - 1; i++) {
            StringBuilder sb = new StringBuilder();
            for (int j = i; j < parts.length; j++) {
                if (j > i) sb.append('.');
                sb.append(parts[j]);
            }
            if (set.contains(sb.toString())) return true;
        }
        return false;
    }

    public static boolean isBlockedQuery(String q) {
        if (q == null) return false;
        return QUERY_EN.matcher(q).find() || QUERY_AR.matcher(q).find();
    }

    /** Returns "site", "query" or null. */
    public static synchronized String blockReason(String url) {
        Uri u;
        try {
            u = Uri.parse(url);
        } catch (Exception e) {
            return null;
        }
        String scheme = u.getScheme();
        if (scheme == null) return null;
        scheme = scheme.toLowerCase(Locale.ROOT);
        if (!scheme.equals("http") && !scheme.equals("https") && !scheme.equals("ws") && !scheme.equals("wss")) {
            return null;
        }
        String host = u.getHost();
        if (host == null) return null;
        host = host.toLowerCase(Locale.ROOT);
        if (inSet(host, haram) || HOST_PATTERN.matcher(host).find()) return "site";
        try {
            for (String k : QUERY_KEYS) {
                String v = u.getQueryParameter(k);
                if (v != null && isBlockedQuery(v)) return "query";
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    public static synchronized boolean isTracker(String url) {
        try {
            return inSet(Uri.parse(url).getHost() == null ? null : Uri.parse(url).getHost().toLowerCase(Locale.ROOT), trackers);
        } catch (Exception e) {
            return false;
        }
    }
}
