package dev.rosto.browser;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Message;
import android.provider.MediaStore;
import android.text.InputType;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.ValueCallback;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.ByteArrayInputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {

    static class Tab {
        WebView web;
        String title = "";
        String url = "";
        String blockedUrl = null;
        boolean dark = false;
        boolean desktop = false;
    }

    static final int BG = 0xFF101820, SURFACE = 0xFF1F2F3D, TEXT = 0xFFE8E4DA, MUTED = 0xFF8FA1AE, ACCENT = 0xFFF2A93B;
    static final int FILE_REQ = 7;
    static final String DESKTOP_UA =
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36";
    static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    final List<Tab> tabs = new ArrayList<>();
    final List<String> net = Collections.synchronizedList(new ArrayList<String>());
    Tab cur;
    FrameLayout content;
    EditText urlBar;
    ProgressBar progress;
    Button tabBtn, backBtn, fwdBtn;
    SharedPreferences sp;
    int blocked = 0;
    boolean ar, adblock = true, httpsOnly = true;
    String engine = "ddg";
    String defaultUA = "";
    View customView;
    WebChromeClient.CustomViewCallback customCb;
    ValueCallback<Uri[]> fileCb;

    String t(String a, String e) {
        return ar ? a : e;
    }

    int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    /* ------------------------------------------------------------ lifecycle */

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("rosto", MODE_PRIVATE);
        ar = Locale.getDefault().getLanguage().equals("ar");
        adblock = sp.getBoolean("adblock", true);
        httpsOnly = sp.getBoolean("https", true);
        engine = sp.getString("engine", "ddg");
        Blocklist.load(sp.getString("userblock", ""));
        WebView.setWebContentsDebuggingEnabled(true);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        buildUi();
        handleIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        handleIntent(i);
    }

    void handleIntent(Intent i) {
        Uri d = i == null ? null : i.getData();
        if (d != null && d.getScheme() != null && d.getScheme().startsWith("http")) {
            openTab(d.toString());
        } else if (tabs.isEmpty()) {
            openTab(null);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (cur != null) cur.web.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (cur != null) cur.web.onResume();
    }

    @Override
    protected void onDestroy() {
        for (Tab t : tabs) t.web.destroy();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (customView != null) {
            hideCustom();
        } else if (cur != null && cur.web.canGoBack()) {
            cur.web.goBack();
        } else if (tabs.size() > 1) {
            closeTab(cur);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == FILE_REQ && fileCb != null) {
            fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            fileCb = null;
        }
    }

    /* ------------------------------------------------------------------- UI */

    void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setFitsSystemWindows(true);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(SURFACE);
        bar.setPadding(dp(4), dp(4), dp(4), dp(4));

        backBtn = barBtn("‹", v -> {
            if (cur != null && cur.web.canGoBack()) cur.web.goBack();
        });
        fwdBtn = barBtn("›", v -> {
            if (cur != null && cur.web.canGoForward()) cur.web.goForward();
        });

        urlBar = new EditText(this);
        urlBar.setSingleLine(true);
        urlBar.setTextColor(TEXT);
        urlBar.setHintTextColor(MUTED);
        urlBar.setHint(t("ابحث أو اكتب عنوان موقع", "Search or enter address"));
        urlBar.setTextSize(14);
        urlBar.setSelectAllOnFocus(true);
        urlBar.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        urlBar.setImeOptions(EditorInfo.IME_ACTION_GO);
        GradientDrawable pill = new GradientDrawable();
        pill.setColor(BG);
        pill.setCornerRadius(dp(20));
        urlBar.setBackground(pill);
        urlBar.setPadding(dp(14), 0, dp(14), 0);
        urlBar.setOnEditorActionListener((v, actionId, ev) -> {
            go(cur, urlBar.getText().toString());
            hideKeyboard();
            return true;
        });

        tabBtn = barBtn("1", v -> showTabs());
        tabBtn.setTextSize(15);
        Button menuBtn = barBtn("⋮", v -> showMenu());

        bar.addView(backBtn, new LinearLayout.LayoutParams(dp(36), dp(40)));
        bar.addView(fwdBtn, new LinearLayout.LayoutParams(dp(36), dp(40)));
        LinearLayout.LayoutParams ulp = new LinearLayout.LayoutParams(0, dp(40), 1f);
        ulp.setMargins(dp(4), 0, dp(4), 0);
        bar.addView(urlBar, ulp);
        bar.addView(tabBtn, new LinearLayout.LayoutParams(dp(40), dp(40)));
        bar.addView(menuBtn, new LinearLayout.LayoutParams(dp(36), dp(40)));

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setProgressTintList(ColorStateList.valueOf(ACCENT));
        progress.setVisibility(View.GONE);

        content = new FrameLayout(this);
        content.setBackgroundColor(BG);

        root.addView(bar, new LinearLayout.LayoutParams(MATCH, WRAP));
        root.addView(progress, new LinearLayout.LayoutParams(MATCH, dp(3)));
        root.addView(content, new LinearLayout.LayoutParams(MATCH, 0, 1f));
        setContentView(root);
    }

    Button barBtn(String label, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(TEXT);
        b.setTextSize(22);
        b.setAllCaps(false);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(0, 0, 0, 0);
        b.setBackgroundColor(0x00000000);
        b.setOnClickListener(l);
        return b;
    }

    void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(urlBar.getWindowToken(), 0);
        urlBar.clearFocus();
        refreshBar();
    }

    void refreshBar() {
        if (cur == null) return;
        backBtn.setAlpha(cur.web.canGoBack() ? 1f : 0.35f);
        fwdBtn.setAlpha(cur.web.canGoForward() ? 1f : 0.35f);
        if (!urlBar.hasFocus()) urlBar.setText(cur.url);
        tabBtn.setText(String.valueOf(tabs.size()));
    }

    /* ----------------------------------------------------------------- tabs */

    Tab newTabBlank() {
        Tab tab = new Tab();
        tab.web = makeWebView(tab);
        tabs.add(tab);
        return tab;
    }

    Tab openTab(String input) {
        Tab tab = newTabBlank();
        switchTo(tab);
        if (input == null) loadHome(tab);
        else go(tab, input);
        return tab;
    }

    void switchTo(Tab tab) {
        if (cur != null) cur.web.onPause();
        cur = tab;
        content.removeAllViews();
        if (tab.web.getParent() != null) ((ViewGroup) tab.web.getParent()).removeView(tab.web);
        content.addView(tab.web, new FrameLayout.LayoutParams(MATCH, MATCH));
        tab.web.onResume();
        progress.setVisibility(View.GONE);
        urlBar.clearFocus();
        refreshBar();
    }

    void closeTab(Tab tab) {
        int i = tabs.indexOf(tab);
        if (i < 0) return;
        content.removeView(tab.web);
        tab.web.destroy();
        tabs.remove(i);
        if (tabs.isEmpty()) {
            cur = null;
            openTab(null);
        } else if (cur == tab) {
            cur = null;
            switchTo(tabs.get(Math.min(i, tabs.size() - 1)));
        } else {
            refreshBar();
        }
    }

    /* -------------------------------------------------------------- web view */

    WebView makeWebView(final Tab tab) {
        WebView w = new WebView(this);
        w.setBackgroundColor(BG);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setSupportMultipleWindows(true);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setSafeBrowsingEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(true);
        if (defaultUA.isEmpty()) defaultUA = s.getUserAgentString();
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, false);

        w.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                String sch = u.getScheme() == null ? "" : u.getScheme().toLowerCase(Locale.ROOT);
                if (sch.equals("rosto")) {
                    handleInternal(tab, u);
                    return true;
                }
                if (sch.equals("http") || sch.equals("https")) {
                    String reason = Blocklist.blockReason(u.toString());
                    if (reason != null) {
                        if (r.isForMainFrame()) showBlocked(tab, u.toString(), reason);
                        return true;
                    }
                    if (httpsOnly && sch.equals("http") && r.isForMainFrame() && !isLocal(u.getHost())) {
                        v.loadUrl(u.toString().replaceFirst("^http:", "https:"));
                        return true;
                    }
                    return false;
                }
                if (sch.equals("about") || sch.equals("data") || sch.equals("blob") || sch.equals("javascript")) {
                    return false;
                }
                if (r.isForMainFrame() && r.hasGesture()) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, u));
                    } catch (Exception ignored) {
                    }
                }
                return true;
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                String u = r.getUrl().toString();
                String sch = r.getUrl().getScheme();
                if (!"http".equals(sch) && !"https".equals(sch)) return null;
                final String reason = Blocklist.blockReason(u);
                if (reason != null) {
                    blocked++;
                    if (r.isForMainFrame()) runOnUiThread(() -> showBlocked(tab, u, reason));
                    return emptyResponse();
                }
                if (adblock && !r.isForMainFrame() && Blocklist.isTracker(u)) {
                    blocked++;
                    return emptyResponse();
                }
                synchronized (net) {
                    net.add(r.getMethod() + " " + u);
                    while (net.size() > 400) net.remove(0);
                }
                return null;
            }

            @Override
            public void onPageStarted(WebView v, String url, android.graphics.Bitmap fav) {
                if (url != null && url.startsWith("rosto://")) {
                    tab.url = tab.blockedUrl == null ? "" : hostOrSelf(tab.blockedUrl);
                } else {
                    tab.url = url == null ? "" : url;
                    tab.blockedUrl = null;
                }
                if (tab == cur) {
                    if (!urlBar.hasFocus()) urlBar.setText(tab.url);
                    refreshBar();
                }
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                tab.title = v.getTitle() == null ? "" : v.getTitle();
                if (tab.dark) applyDark(tab);
                if (url != null && url.startsWith("http")) addHistory(tab.title, url);
                if (tab == cur) refreshBar();
            }
        });

        w.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView v, int p) {
                if (tab != cur) return;
                progress.setProgress(p);
                progress.setVisibility(p < 100 ? View.VISIBLE : View.GONE);
            }

            @Override
            public void onReceivedTitle(WebView v, String title) {
                tab.title = title == null ? "" : title;
            }

            @Override
            public boolean onCreateWindow(WebView v, boolean isDialog, boolean isUserGesture, Message msg) {
                if (!isUserGesture) return false;
                Tab nt = newTabBlank();
                switchTo(nt);
                WebView.WebViewTransport tr = (WebView.WebViewTransport) msg.obj;
                tr.setWebView(nt.web);
                msg.sendToTarget();
                return true;
            }

            @Override
            public void onShowCustomView(View view, CustomViewCallback cb) {
                if (customView != null) {
                    cb.onCustomViewHidden();
                    return;
                }
                customView = view;
                customCb = cb;
                ((FrameLayout) getWindow().getDecorView()).addView(view, new FrameLayout.LayoutParams(MATCH, MATCH));
                getWindow().getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
            }

            @Override
            public void onHideCustomView() {
                hideCustom();
            }

            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                try {
                    startActivityForResult(p.createIntent(), FILE_REQ);
                } catch (Exception e) {
                    fileCb = null;
                    return false;
                }
                return true;
            }
        });

        w.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String ua, String cd, String mime, long len) {
                try {
                    DownloadManager.Request rq = new DownloadManager.Request(Uri.parse(url));
                    String fn = URLUtil.guessFileName(url, cd, mime);
                    rq.setMimeType(mime);
                    rq.addRequestHeader("User-Agent", ua);
                    String ck = CookieManager.getInstance().getCookie(url);
                    if (ck != null) rq.addRequestHeader("Cookie", ck);
                    rq.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    rq.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fn);
                    ((DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE)).enqueue(rq);
                    toast(t("بدأ التحميل: ", "Download started: ") + fn);
                } catch (Exception e) {
                    toast(t("فشل التحميل", "Download failed"));
                }
            }
        });
        return w;
    }

    WebResourceResponse emptyResponse() {
        return new WebResourceResponse("text/plain", "utf-8", new ByteArrayInputStream(new byte[0]));
    }

    void hideCustom() {
        if (customView == null) return;
        ((FrameLayout) getWindow().getDecorView()).removeView(customView);
        customView = null;
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
        if (customCb != null) customCb.onCustomViewHidden();
        customCb = null;
    }

    boolean isLocal(String host) {
        if (host == null) return false;
        return host.equals("localhost") || host.startsWith("127.") || host.startsWith("10.")
                || host.startsWith("192.168.") || host.matches("^172\\.(1[6-9]|2\\d|3[01])\\..*");
    }

    String hostOrSelf(String url) {
        try {
            String h = Uri.parse(url).getHost();
            return h == null ? url : h;
        } catch (Exception e) {
            return url;
        }
    }

    /* ----------------------------------------------------------- navigation */

    void go(Tab tab, String input) {
        if (tab == null || input == null) return;
        input = input.trim();
        if (input.isEmpty()) return;
        String url;
        if (input.matches("(?i)^https?://\\S+$")) {
            url = input;
        } else if (input.matches("(?i)^(localhost|\\d{1,3}(\\.\\d{1,3}){3})(:\\d+)?([/?#]\\S*)?$")) {
            url = "http://" + input;
        } else if (input.matches("^[^\\s/]+\\.[^\\s./:]{2,}(:\\d+)?([/?#]\\S*)?$")) {
            url = "https://" + input;
        } else {
            if (Blocklist.isBlockedQuery(input)) {
                showBlocked(tab, input, "query");
                return;
            }
            url = searchUrl(input);
        }
        String reason = Blocklist.blockReason(url);
        if (reason != null) {
            showBlocked(tab, url, reason);
            return;
        }
        tab.blockedUrl = null;
        tab.web.loadUrl(url);
    }

    String searchUrl(String q) {
        String e = Uri.encode(q);
        switch (engine) {
            case "brave":
                return "https://search.brave.com/search?q=" + e + "&safesearch=strict";
            case "google":
                return "https://www.google.com/search?q=" + e + "&safe=active";
            case "bing":
                return "https://www.bing.com/search?q=" + e + "&adlt=strict";
            default:
                return "https://duckduckgo.com/?q=" + e + "&kp=1";
        }
    }

    void handleInternal(Tab tab, Uri u) {
        String host = u.getHost() == null ? "" : u.getHost();
        switch (host) {
            case "s":
                go(tab, u.getQueryParameter("q"));
                break;
            case "go":
                go(tab, u.getQueryParameter("u"));
                break;
            case "home":
                tab.blockedUrl = null;
                loadHome(tab);
                break;
            default:
                break;
        }
    }

    void showBlocked(Tab tab, String url, String reason) {
        tab.blockedUrl = url;
        boolean q = "query".equals(reason);
        String html = """
                <!doctype html><html dir="__DIR__"><head><meta charset="utf-8">
                <meta name="viewport" content="width=device-width,initial-scale=1">
                <style>
                html,body{margin:0;height:100%;background:#101820;color:#E8E4DA;font-family:Cairo,Tahoma,sans-serif}
                body{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:14px;padding:24px;box-sizing:border-box;text-align:center}
                .s{font-size:64px;color:#E0604F}
                h2{margin:0;font-size:22px}
                p{margin:0;color:#8FA1AE;line-height:1.8;max-width:36ch}
                code{direction:ltr;background:#17232E;padding:3px 10px;border-radius:6px;max-width:90vw;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
                a{display:inline-block;margin-top:8px;padding:10px 22px;background:#F2A93B;color:#1a1205;border-radius:8px;text-decoration:none;font-weight:700}
                </style></head><body>
                <div class="s">&#9951;</div>
                <h2>__TITLE__</h2><p>__TEXT__</p>__CODE__
                <a href="rosto://home">__HOME__</a>
                </body></html>
                """;
        html = html.replace("__DIR__", ar ? "rtl" : "ltr")
                .replace("__TITLE__", q ? t("ROSTO حجب البحث ده", "ROSTO blocked this search")
                        : t("ROSTO حجب الموقع ده", "ROSTO blocked this site"))
                .replace("__TEXT__", q ? t("كلمات البحث دي محظورة. جرّب بحث تاني.", "These search terms are blocked. Try another search.")
                        : t("الموقع فيه محتوى محرم، فاتحجب تلقائياً لحمايتك.", "This site has forbidden content and was blocked automatically."))
                .replace("__CODE__", q ? "" : "<code>" + TextUtils.htmlEncode(hostOrSelf(url)) + "</code>")
                .replace("__HOME__", t("الرئيسية", "Home"));
        tab.web.loadDataWithBaseURL("rosto://blocked/", html, "text/html", "utf-8", null);
        toast(t("تم الحجب", "Blocked") + " (" + blocked + ")");
    }

    void loadHome(Tab tab) {
        List<String[]> list = new ArrayList<>();
        JSONArray bm = loadList("bookmarks");
        for (int i = 0; i < bm.length() && list.size() < 8; i++) {
            JSONObject o = bm.optJSONObject(i);
            if (o != null) list.add(new String[]{o.optString("t"), o.optString("u")});
        }
        String[][] defs = {{"Wikipedia", "https://wikipedia.org"}, {"YouTube", "https://m.youtube.com"},
                {"GitHub", "https://github.com"}, {"MDN", "https://developer.mozilla.org"},
                {"Stack Overflow", "https://stackoverflow.com"}, {"Reddit", "https://www.reddit.com"}};
        for (String[] d : defs) if (list.size() < 12) list.add(d);
        StringBuilder tiles = new StringBuilder();
        for (String[] x : list) {
            String name = x[0] == null || x[0].isEmpty() ? hostOrSelf(x[1]) : x[0];
            String letter = name.isEmpty() ? "?" : name.substring(0, 1).toUpperCase();
            tiles.append("<a class=\"tile\" href=\"rosto://go?u=").append(Uri.encode(x[1])).append("\"><i>")
                    .append(TextUtils.htmlEncode(letter)).append("</i><span>")
                    .append(TextUtils.htmlEncode(name)).append("</span></a>");
        }
        String html = """
                <!doctype html><html dir="__DIR__"><head><meta charset="utf-8">
                <meta name="viewport" content="width=device-width,initial-scale=1">
                <style>
                html,body{margin:0;height:100%;background:#101820;color:#E8E4DA;font-family:Cairo,Tahoma,sans-serif}
                body{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:26px;padding:20px;box-sizing:border-box}
                h1{margin:0;font-size:18vw;letter-spacing:.12em;font-weight:800;line-height:1;direction:ltr;padding-left:.12em}
                h1 span{color:#F2A93B}
                input{width:100%;max-width:560px;height:48px;border-radius:24px;border:1px solid #2B3E4E;background:#17232E;color:#E8E4DA;padding:0 20px;font-size:16px;outline:0;box-sizing:border-box}
                input:focus{border-color:#F2A93B}
                .g{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;width:100%;max-width:560px}
                .tile{display:flex;flex-direction:column;align-items:center;gap:6px;padding:10px 4px;border-radius:10px;background:#17232E;color:#E8E4DA;text-decoration:none;font-size:11px}
                .tile i{width:34px;height:34px;border-radius:50%;background:#2B3E4E;display:grid;place-items:center;font-style:normal;font-weight:700;color:#F2A93B}
                .tile span{max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
                </style></head><body>
                <h1>ROST<span>O</span></h1>
                <input id="q" placeholder="__PH__" autocomplete="off" enterkeyhint="search">
                <div class="g">__TILES__</div>
                <script>document.getElementById('q').addEventListener('keydown',function(e){if(e.key==='Enter'&&this.value.trim()){location.href='rosto://s?q='+encodeURIComponent(this.value.trim());}});</script>
                </body></html>
                """;
        html = html.replace("__DIR__", ar ? "rtl" : "ltr")
                .replace("__PH__", t("ابحث في الإنترنت…", "Search the web…"))
                .replace("__TILES__", tiles.toString());
        tab.blockedUrl = null;
        tab.web.loadDataWithBaseURL("rosto://home/", html, "text/html", "utf-8", null);
    }

    /* ------------------------------------------------------ storage helpers */

    JSONArray loadList(String key) {
        try {
            return new JSONArray(sp.getString(key, "[]"));
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    void saveList(String key, JSONArray a) {
        sp.edit().putString(key, a.toString()).apply();
    }

    void addHistory(String title, String url) {
        try {
            JSONArray old = loadList("history");
            JSONArray out = new JSONArray();
            JSONObject n = new JSONObject();
            n.put("t", title.isEmpty() ? url : title);
            n.put("u", url);
            out.put(n);
            for (int i = 0; i < old.length() && out.length() < 200; i++) {
                JSONObject o = old.optJSONObject(i);
                if (o != null && !url.equals(o.optString("u"))) out.put(o);
            }
            saveList("history", out);
        } catch (Exception ignored) {
        }
    }

    boolean isBookmarked(String url) {
        JSONArray a = loadList("bookmarks");
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o != null && url.equals(o.optString("u"))) return true;
        }
        return false;
    }

    void toggleBookmark() {
        String url = cur.url;
        if (!url.startsWith("http")) {
            toast(t("افتح صفحة الأول", "Open a page first"));
            return;
        }
        try {
            JSONArray a = loadList("bookmarks");
            JSONArray out = new JSONArray();
            boolean had = false;
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.optJSONObject(i);
                if (o == null) continue;
                if (url.equals(o.optString("u"))) had = true;
                else out.put(o);
            }
            if (!had) {
                JSONObject n = new JSONObject();
                n.put("t", cur.title.isEmpty() ? url : cur.title);
                n.put("u", url);
                JSONArray withNew = new JSONArray();
                withNew.put(n);
                for (int i = 0; i < out.length(); i++) withNew.put(out.get(i));
                out = withNew;
            }
            saveList("bookmarks", out);
            toast(had ? t("اتشالت من المفضلة", "Bookmark removed") : t("اتحفظت في المفضلة", "Bookmarked"));
        } catch (Exception ignored) {
        }
    }

    /* ------------------------------------------------------------- dialogs */

    void showMenu() {
        final boolean pageOk = cur != null && cur.url.startsWith("http");
        String on = " ✓", off = "";
        final String[] items = {
                t("تبويب جديد", "New tab"),
                (pageOk && isBookmarked(cur.url)) ? t("شيل من المفضلة", "Remove bookmark") : t("أضف للمفضلة", "Add bookmark"),
                t("المفضلة", "Bookmarks"),
                t("السجل", "History"),
                t("بحث في الصفحة", "Find in page"),
                t("نسخة الكمبيوتر", "Desktop site") + (cur != null && cur.desktop ? on : off),
                t("وضع ليلي للصفحة", "Page dark mode") + (cur != null && cur.dark ? on : off),
                t("الكود المصدري", "View source"),
                t("كونسول (تشغيل JavaScript)", "Console (run JavaScript)"),
                t("سجل الشبكة", "Network log"),
                t("لقطة شاشة", "Screenshot"),
                t("مشاركة الرابط", "Share link"),
                t("ترجمة الصفحة", "Translate page"),
                t("حجب الإعلانات والتتبع", "Block ads and trackers") + (adblock ? on : off),
                t("فرض HTTPS", "Force HTTPS") + (httpsOnly ? on : off),
                t("محرك البحث", "Search engine"),
                t("بلّغ عن الموقع (حجب)", "Report site (block)"),
                t("امسح الكوكيز والكاش", "Clear cookies and cache"),
                t("أدوات المطور من الكمبيوتر", "DevTools from a PC")
        };
        new AlertDialog.Builder(this)
                .setTitle("ROSTO  ⛨ " + blocked)
                .setItems(items, (d, which) -> menuAction(which))
                .show();
    }

    void menuAction(int which) {
        switch (which) {
            case 0:
                openTab(null);
                break;
            case 1:
                toggleBookmark();
                break;
            case 2:
                showList(t("المفضلة", "Bookmarks"), "bookmarks");
                break;
            case 3:
                showList(t("السجل", "History"), "history");
                break;
            case 4:
                showFind();
                break;
            case 5:
                toggleDesktop();
                break;
            case 6:
                cur.dark = !cur.dark;
                applyDark(cur);
                break;
            case 7:
                viewSource();
                break;
            case 8:
                showConsole();
                break;
            case 9:
                synchronized (net) {
                    showText(t("سجل الشبكة", "Network log"), TextUtils.join("\n", net), true);
                }
                break;
            case 10:
                screenshot();
                break;
            case 11:
                if (cur.url.startsWith("http")) {
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("text/plain");
                    i.putExtra(Intent.EXTRA_TEXT, cur.url);
                    startActivity(Intent.createChooser(i, "ROSTO"));
                }
                break;
            case 12:
                if (cur.url.startsWith("http")) {
                    go(cur, "https://translate.google.com/translate?sl=auto&tl=" + (ar ? "ar" : "en")
                            + "&u=" + Uri.encode(cur.url));
                }
                break;
            case 13:
                adblock = !adblock;
                sp.edit().putBoolean("adblock", adblock).apply();
                toast(adblock ? t("الحجب شغال", "Ad block on") : t("الحجب موقوف", "Ad block off"));
                break;
            case 14:
                httpsOnly = !httpsOnly;
                sp.edit().putBoolean("https", httpsOnly).apply();
                toast(httpsOnly ? "HTTPS ✓" : "HTTPS ✗");
                break;
            case 15:
                pickEngine();
                break;
            case 16:
                reportSite();
                break;
            case 17:
                CookieManager.getInstance().removeAllCookies(null);
                WebStorage.getInstance().deleteAllData();
                for (Tab tb : tabs) tb.web.clearCache(true);
                toast(t("اتمسح", "Cleared"));
                break;
            case 18:
                showText(t("أدوات المطور من الكمبيوتر", "DevTools from a PC"),
                        t("1) وصّل التليفون بالكمبيوتر بكابل USB وفعّل تصحيح USB.\n"
                                        + "2) افتح كروم على الكمبيوتر واكتب: chrome://inspect\n"
                                        + "3) هتلاقي صفحات ROSTO في القايمة، اضغط inspect وهتفتح لك أدوات المطور كاملة (عناصر، كونسول، شبكة، مصادر).",
                                "1) Connect the phone to a PC by USB and enable USB debugging.\n"
                                        + "2) On the PC open Chrome and go to: chrome://inspect\n"
                                        + "3) ROSTO pages are listed there. Click inspect to get full DevTools (Elements, Console, Network, Sources)."),
                        false);
                break;
            default:
                break;
        }
    }

    void showTabs() {
        String[] names = new String[tabs.size()];
        for (int i = 0; i < tabs.size(); i++) {
            Tab tb = tabs.get(i);
            String n = !tb.title.isEmpty() ? tb.title : (!tb.url.isEmpty() ? tb.url : t("تبويب جديد", "New tab"));
            names[i] = (tb == cur ? "● " : "○ ") + n;
        }
        new AlertDialog.Builder(this)
                .setTitle(t("التبويبات", "Tabs"))
                .setItems(names, (d, i) -> switchTo(tabs.get(i)))
                .setPositiveButton("+", (d, i) -> openTab(null))
                .setNeutralButton(t("اقفل التبويب", "Close tab"), (d, i) -> closeTab(cur))
                .show();
    }

    void showList(String title, final String key) {
        final JSONArray a = loadList(key);
        final String[] names = new String[a.length()];
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            names[i] = o == null ? "" : o.optString("t") + "\n" + o.optString("u");
        }
        if (names.length == 0) {
            toast(t("فاضي", "Empty"));
            return;
        }
        AlertDialog.Builder b = new AlertDialog.Builder(this)
                .setTitle(title + "  (" + t("اضغط مطولاً للحذف", "long-press to delete") + ")")
                .setItems(names, (d, i) -> {
                    JSONObject o = a.optJSONObject(i);
                    if (o != null) go(cur, o.optString("u"));
                });
        if (key.equals("history")) {
            b.setNeutralButton(t("امسح السجل", "Clear history"), (d, i) -> saveList("history", new JSONArray()));
        }
        final AlertDialog dlg = b.create();
        dlg.show();
        dlg.getListView().setOnItemLongClickListener((p, v, pos, id) -> {
            try {
                JSONArray out = new JSONArray();
                for (int i = 0; i < a.length(); i++) if (i != pos) out.put(a.get(i));
                saveList(key, out);
            } catch (Exception ignored) {
            }
            dlg.dismiss();
            showList(title, key);
            return true;
        });
    }

    void showFind() {
        final EditText et = new EditText(this);
        et.setSingleLine(true);
        et.setHint(t("بحث في الصفحة", "Find in page"));
        final AlertDialog d = new AlertDialog.Builder(this)
                .setTitle(t("بحث في الصفحة", "Find in page"))
                .setView(et)
                .setPositiveButton(t("التالي", "Next"), null)
                .setNegativeButton(t("إغلاق", "Close"), (x, i) -> cur.web.clearMatches())
                .create();
        d.show();
        d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String q = et.getText().toString();
            if (q.isEmpty()) return;
            cur.web.findAllAsync(q);
            cur.web.findNext(true);
        });
    }

    void showConsole() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(16), dp(8), dp(16), 0);
        final TextView out = new TextView(this);
        out.setTypeface(Typeface.MONOSPACE);
        out.setTextSize(12);
        out.setTextColor(TEXT);
        final ScrollView sv = new ScrollView(this);
        sv.addView(out);
        l.addView(sv, new LinearLayout.LayoutParams(MATCH, dp(200)));
        final EditText in = new EditText(this);
        in.setSingleLine(true);
        in.setHint("document.title");
        in.setTypeface(Typeface.MONOSPACE);
        l.addView(in, new LinearLayout.LayoutParams(MATCH, WRAP));
        final AlertDialog d = new AlertDialog.Builder(this)
                .setTitle(t("كونسول", "Console"))
                .setView(l)
                .setPositiveButton("Run", null)
                .setNegativeButton(t("إغلاق", "Close"), null)
                .create();
        d.show();
        d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String code = in.getText().toString();
            if (code.trim().isEmpty()) return;
            out.append("› " + code + "\n");
            in.setText("");
            cur.web.evaluateJavascript(code, res -> {
                out.append(res + "\n\n");
                sv.post(() -> sv.fullScroll(View.FOCUS_DOWN));
            });
        });
    }

    void showText(String title, final String text, boolean mono) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(12);
        tv.setTextIsSelectable(true);
        tv.setTextColor(TEXT);
        if (mono) tv.setTypeface(Typeface.MONOSPACE);
        tv.setPadding(dp(16), dp(8), dp(16), dp(8));
        ScrollView sv = new ScrollView(this);
        sv.addView(tv);
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setView(sv)
                .setPositiveButton(t("إغلاق", "Close"), null)
                .setNeutralButton(t("نسخ", "Copy"), (d, i) -> {
                    ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    cm.setPrimaryClip(ClipData.newPlainText("ROSTO", text));
                    toast(t("اتنسخ", "Copied"));
                })
                .show();
    }

    void pickEngine() {
        final String[] keys = {"ddg", "brave", "google", "bing"};
        String[] names = {"DuckDuckGo", "Brave", "Google", "Bing"};
        int sel = 0;
        for (int i = 0; i < keys.length; i++) if (keys[i].equals(engine)) sel = i;
        new AlertDialog.Builder(this)
                .setTitle(t("محرك البحث", "Search engine"))
                .setSingleChoiceItems(names, sel, (d, i) -> {
                    engine = keys[i];
                    sp.edit().putString("engine", engine).apply();
                    d.dismiss();
                })
                .show();
    }

    /* ---------------------------------------------------------------- tools */

    void toggleDesktop() {
        cur.desktop = !cur.desktop;
        WebSettings s = cur.web.getSettings();
        s.setUserAgentString(cur.desktop ? DESKTOP_UA : defaultUA);
        s.setUseWideViewPort(cur.desktop);
        s.setLoadWithOverviewMode(cur.desktop);
        cur.web.reload();
    }

    void applyDark(Tab tab) {
        String js = tab.dark
                ? "(function(){if(document.getElementById('rosto-dark'))return;var s=document.createElement('style');s.id='rosto-dark';"
                + "s.textContent='html{filter:invert(1) hue-rotate(180deg)!important;background:#fff}"
                + "img,video,canvas,picture{filter:invert(1) hue-rotate(180deg)!important}';document.documentElement.appendChild(s)})()"
                : "(function(){var s=document.getElementById('rosto-dark');if(s)s.remove()})()";
        tab.web.evaluateJavascript(js, null);
    }

    void viewSource() {
        if (!cur.url.startsWith("http")) {
            toast(t("افتح صفحة الأول", "Open a page first"));
            return;
        }
        cur.web.evaluateJavascript("document.documentElement.outerHTML", res -> {
            String src;
            try {
                src = (String) new JSONTokener(res).nextValue();
            } catch (Exception e) {
                src = String.valueOf(res);
            }
            if (src.length() > 150000) src = src.substring(0, 150000) + "\n…";
            showText(t("الكود المصدري", "Source"), src, true);
        });
    }

    void screenshot() {
        WebView w = cur.web;
        if (w.getWidth() == 0 || w.getHeight() == 0) return;
        try {
            Bitmap b = Bitmap.createBitmap(w.getWidth(), w.getHeight(), Bitmap.Config.ARGB_8888);
            w.draw(new Canvas(b));
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.Images.Media.DISPLAY_NAME, "rosto-" + System.currentTimeMillis() + ".png");
            cv.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
            cv.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ROSTO");
            Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
            if (uri == null) throw new IllegalStateException("insert failed");
            try (OutputStream os = getContentResolver().openOutputStream(uri)) {
                b.compress(Bitmap.CompressFormat.PNG, 100, os);
            }
            toast(t("اتحفظت اللقطة في Pictures/ROSTO", "Saved to Pictures/ROSTO"));
        } catch (Exception e) {
            toast(t("فشلت اللقطة", "Screenshot failed"));
        }
    }

    void reportSite() {
        String host = cur.url.startsWith("http") ? hostOrSelf(cur.url) : "";
        if (Blocklist.addUser(host)) {
            sp.edit().putString("userblock", Blocklist.userCsv()).apply();
            toast(t("اتضاف الموقع لقايمة الحجب", "Site added to the blocklist"));
            showBlocked(cur, cur.url, "site");
        } else {
            toast(t("افتح صفحة الأول", "Open a page first"));
        }
    }
}
